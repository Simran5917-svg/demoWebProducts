<!DOCTYPE html>
<html>
<head>
<title>Student Registration form</title>
</head>

<body>
  <center> <h1> Registration Form </h1> </center>   

	<form method="post" id="frm_register" name="frm_register" action="<?php echo base_url();?>index.php/register">
    
		<table width="600" align="center" border="1" cellspacing="5" cellpadding="5">
	<tr>
		<td colspan="2"><?php echo validation_errors(); ?>

    <?php echo form_open('form'); ?><?php echo @$error; ?></td>
	</tr>	
  <tr>
    <td width="230"> Name: </td>
    <td width="329"><input type="text" name="name" /></td>
  </tr>
  
  <tr>
    <td> Email: </td>
    <td><input type="text" name="email" /></td>
  </tr>
  
  <tr>
    <td> Password: </td>
    <td><input type="password" name="pass" /></td>
  </tr>
  
  <tr>
    <td> Type: </td>
    <td>
	<select name="type" >
		<option value="">Select type</option>
		<option value="user">User</option>
		<option value="admin">Admin</option>
		
	</select>
	</td>
  </tr>
  
  <tr>
    <td colspan="2" align="center">
	<input type="submit" name="register" value="Register Me"/>
  <a href="<?php echo base_url();?>">Login</a> </td>
  </tr>
</table>

	</form>
</body>
</html>