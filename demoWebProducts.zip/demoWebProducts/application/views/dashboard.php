<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  border: 1px solid black;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  border: 1px solid black;
}

tr:nth-child(even) {
  background-color: #dddddd;
  border: 1px solid black;
}
input[type=text] {
		  width: 130px;
		  box-sizing: border-box;
		  border: 2px solid #ccc;
		  border-radius: 4px;
		  font-size: 16px;
		  background-color: white;
		  background-image: url('searchicon.png');
		  background-position: 10px 10px; 
		  background-repeat: no-repeat;
		  padding: 12px 20px 12px 40px;
		  -webkit-transition: width 0.4s ease-in-out;
		  transition: width 0.4s ease-in-out;
		}

		input[type=text]:focus {
		  width: 100%;
		}
</style>
<script type="text/javascript">
  $(function(){
   $("#search").keyup( function() {
            // alert("dfdf");
     var searchQuery = $("#search").val();
    // alert(searchQuery);
         $.ajax({
            type: 'post',
            url: '<?php echo base_url(); ?>index.php/searchText',
            data:{"searchQuery":searchQuery},
            success: function (data) {
              //alert(data);
              $('#product_details').html(data);
            }
          });
       });
   });
</script>
</head>
<body>

<button class='btn btn-success pull-right' onclick="window.location.href='<?php echo base_url(); ?>index.php/logout';">Logout</button>

<table id="product_details">
	<h3>Welcome <?php echo ($fullname);?>...</h3>
  <tr class="container">
   <button class='btn btn-success pull-left' onclick="window.location.href='<?php echo base_url(); ?>index.php/add_product';">Add Product</button>

</tr>
<br/>
  <h2>Product List Data Table
  <form>
	  <input type="text" name="search" id="search" placeholder="Search By Name..">
	</form></h2>
  <tr>
    <th>SL No.</th>
    <th>Product Name</th>
    <th>Price</th>
    <th>Color</th>
    <th>Action</th>
  </tr>
  <?php foreach($data as $key=>$product){ ?>
  <tr>
    <td><?php echo $key+1;?></td>
    <td><?php echo $product->name;?></td>
    <td><?php echo $product->price;?></td>
    <td><?php echo $product->color;?></td>
    <td><button id="edit">Edit</button></td>
  </tr>
<?php } ?>
</table>

</body>
</html>