<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>A free Bootstrap / HTML5 / CSS3 product display template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">

    <!-- Google Web Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Poiret+One' rel='stylesheet' type='text/css'>    
        <link href='http://fonts.googleapis.com/css?family=Indie Flower&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
            
        <!--Choco bar Theme CSS style -->
        <link href="<?php echo base_url();?>assets/css/products.css" rel="stylesheet">     
        
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.css">   
        


   
                        
</head>
  <body >

<!-- Special Products section starts-->
    <div class="section outdiv" id="specialities">
       <div class="container">
        <div class="col-md-12"><h1 class="text-center wow pulse"><span>Our Specialities</span></h1>
            <p class="sub-headers text-center">Top rated by customers!</p>
      
                <div class="speciality wow fadeIn" data-wow-delay="0.6s">

               <?php foreach($products as $pdt){?>
               <a href="<?php echo base_url();?>index.php/demo/<?php echo str_replace(' ','_',$pdt->name);?>">
               <div class="spe-prods">
                  <div class="mainbox">
                                <img class="rotprod" src="<?php echo base_url();?>assets/images/<?php echo $pdt->image;?>" alt="">
                  </div>
                  <div>
                    <div>
                        <h3><b>$<?php echo $pdt->price;?> BDT</b></h3>
                        <h3><b><?php echo $pdt->name;?></b></h3>
                    </div>
                  </div>
               </div>
             </a>
             <?php } ?>
              </div>
           </div>   
         </div>
       </div>                           
        
<!--Special Products Ending here --> 




<!-- Required JavaScript libraris collection -->    
<!--The jQuery library from local-->    
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<!-- Bootstrap library from local -->        
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
        
        <!-- In own hosting -->
        <!-- <script src="<?php echo base_url();?>assets/js/wow.min.js"></script>-->
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
        
<script>
        //Initializing WOW aninations
          new WOW().init();
</script>

  </body>
</html>                    