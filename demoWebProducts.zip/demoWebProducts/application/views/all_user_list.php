<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  //font-family: arial, sans-serif;
  //border-collapse: collapse;
  width: 60%;
  border: 1px solid black;
  text-align:right; float:right;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  border: 1px solid black;
}

tr:nth-child(even) {
  background-color: #dddddd;
  border: 1px solid black;
}
input[type=text] {
      width: 130px;
      box-sizing: border-box;
      border: 2px solid #ccc;
      border-radius: 4px;
      font-size: 16px;
      background-color: white;
      background-image: url('searchicon.png');
      background-position: 10px 10px; 
      background-repeat: no-repeat;
      padding: 12px 20px 12px 40px;
      -webkit-transition: width 0.4s ease-in-out;
      transition: width 0.4s ease-in-out;
    }

    input[type=text]:focus {
      width: 100%;
    }
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="<?php echo base_url();?>index.php/admin_dashboard">Menu</a>
  <a href="<?php echo base_url();?>index.php/all_user_list">All User List</a>
  <a href="<?php echo base_url();?>index.php/product_list">Product List</a>
    <a href="<?php echo base_url();?>index.php/logout">Logout</a>
</div>

<h2>Welcome to Admin Dashboard</h2>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

<table id="product_details">
   <h2 style="width: 60%;
  border: 1px solid black;
  text-align:right; float:right;">
 
   <center>All Registered Users<br> <input type="text" name="search" id="search" placeholder="Search By Name.."></center>
  </h2>
  <tr>
    <th>SL No.</th>
    <th>User Name</th>
    <th>Count</th>
  </tr>
  <?php 
  //print_r($user);
  foreach($user as $key=>$user_list){
  $query = $this->db->query("SELECT COUNT(`user_id`) AS count FROM `product_details` WHERE user_id='".$user_list['id']."'");
  $user = $query->result_array();
  //print_r($user[0]['count']);
  ?>
  <tr>
    <td><?php echo $key+1;?></td>
    <td><?php echo $user_list['name'];?></td>
    <td><?php echo $user[0]['count'];?></td>
  </tr>
<?php
   }
?>

</table>
<br/>
<br/>
<div style="width: 60%;
  border: 1px solid black;
  text-align:right; float:right;"><?php echo $links; ?></div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script type="text/javascript">
  $(function(){
   $("#search").keyup( function() {
            // alert("dfdf");
     var searchQuery = $("#search").val();
    // alert(searchQuery);
         $.ajax({
            type: 'post',
            url: '<?php echo base_url(); ?>index.php/searchOwnerName',
            data:{"searchQuery":searchQuery},
            success: function (data) {
              //alert(data);
              $('#product_details').html(data);
            }
          });
       });
   });
</script>
   
</body>
</html> 
