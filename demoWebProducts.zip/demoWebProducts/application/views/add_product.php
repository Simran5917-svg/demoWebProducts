<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  border: 1px solid black;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  border: 1px solid black;
}

tr:nth-child(even) {
  background-color: #dddddd;
  border: 1px solid black;
}
</style>
</head>
<body>

<button class='btn btn-success pull-right' onclick="window.location.href='<?php echo base_url(); ?>index.php/logout';">Logout</button>
<form action="<?php echo base_url();?>index.php/add_product" id="frm" name="frm" method="post" enctype="multipart/form-data">
  <table>
      <tr class="container">
       <button type="button" class='btn btn-success pull-left' onclick="window.location.href='<?php echo base_url(); ?>index.php/dashboard';">Product List</button>
    </tr>
    <br/>
      <h2>Add Product Information</h2>
      <tr>
        <td colspan="2" style="color: red;"><?php echo validation_errors(); ?>

        <?php echo form_open('form'); ?><?php echo @$error; ?></td>
      </tr> 
      
        <input type="hidden" name="email" id="email" value="<?php echo $this->session->userdata('email'); ?>">
        <tr><th><input type="text" name="pdt_name" id="pdt_name" placeholder="Product Name"></th></tr>
        <tr><th><input type="text" name="pdt_price" id="pdt_price" placeholder="Price"></th></tr>
        <tr><th><input type="text" name="pdt_color" id="pdt_color" placeholder="Color"></th></tr>
        <tr><th><input type="file" name="pdt_image" id="pdt_image"></th></tr>
        <tr><th>
        <select name="status" id="status">
          <option value="1">Publish</option>
          <option value="0">Inactive</option>
        </select>
       </th></tr>
       <tr><th><input type="button" name="reset" id="reset" value="Reset">
        <input type="submit" name="save" id="save" value="Save"></th></tr>

  </table>
</form>
<script type="text/javascript">
  $("#reset").click(function(){
    //alert();
     $("#pdt_name").val("");
     $("#pdt_price").val("");
     $("#pdt_color").val("");
  });
</script>

</body>
</html>