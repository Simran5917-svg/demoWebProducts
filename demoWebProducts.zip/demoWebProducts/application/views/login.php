<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> Login Page </title>  
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: gray;  
}  
button {   
       background-color: #4CAF50;   
       width: 100%;  
        color: orange;   
        padding: 15px;   
        margin: 10px 0px;   
        border: none;   
        cursor: pointer;   
         }   
 form {   
        border: 3px solid #f1f1f1;   
    }   
 input[type=text], input[type=password],select {   
        width: 100%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid green;   
        box-sizing: border-box;   
    }  
 button:hover {   
        opacity: 0.7;   
    }   
  .cancelbtn {   
        width: auto;   
        padding: 10px 18px;  
        margin: 10px 5px;  
    }   
        
     
 .container {   
        padding: 25px;   
        background-color: white;  
    }   
</style>   
</head>    
<body>    

    <center> <h1>Web Products<span> Login Page</span>  </h1> </center>   
    <?php echo validation_errors();?>

    <?php 
      if(!empty($this->session->userdata('expired')))
        echo $this->session->userdata('expired');
     ?>
    <form id="login_frm" name="login_frm" method="post" action="<?php echo base_url();?>">  
        <div class="container">   
            <label>Email : </label>   
            <input type="text" placeholder="Enter Email" name="email" >  
            <label>Password : </label>   
            <input type="password" placeholder="Enter Password" name="password" > 
            Login Type :
            <select name="type">
                <option value="">Select User Type</option>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit" id="login" name="login">Login</button>
            <a href="<?php echo base_url();?>index.php/register">Register</a>   
            <!-- <input type="checkbox" checked="checked"> Remember me    -->
            <!-- <button type="button" class="cancelbtn"> Cancel</button>   --> 
            <!-- Forgot <a href="#"> password? </a>  -->  
        </div>   
    </form>     
</body>     
</html>  