<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class LoginController extends CI_Controller {  
      

    public function __construct()
    {
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
        $this->load->model('User_model');
        $this->load->helper('security');  
        $this->load->library('form_validation');  
    }
    public function index()  
    {  

        if(isset($_POST["login"])){
  
            $this->form_validation->set_rules('email', 'Email:', 'required|valid_email');  
            $this->form_validation->set_rules('password', 'Password:', 'required'); 
            $this->form_validation->set_rules('type', 'User Type:', 'required'); 
            if($this->form_validation->run()){
                $email = $this->input->post('email');  
                $pass = $this->input->post('password');
                $type = $this->input->post('type');
                //echo $email;
                $user=$this->User_model->getUsers($email);
                
                if (!empty($user) && $user[0]->email==$email && $user[0]->password==md5($pass) && $user[0]->type==$type && $user[0]->type=="user" )   
                {  
                    //declaring session  
                    $this->session->set_userdata('email',$email); 
                    redirect('dashboard');  
                    //redirect(base_url()."dashboard".$data);

                }else if(!empty($user) && $user[0]->email==$email && $user[0]->password==md5($pass) && $user[0]->type==$type && $user[0]->type=="admin"){
                   // echo "sim";
                    $this->session->set_userdata(array('admin_email'=>$email));  
                    redirect('admin_dashboard');
                }  
                else{ 
               // echo "bar"; 
                    $data['error'] = 'Your Account is Invalid';  
                    $this->load->view('login', $data);  
                }  
            }else
            $this->load->view('login');
        }
        else
        $this->load->view('login');
        
    }  
    public function logout()  
    {  
        //removing session  
        if(!empty( $this->session->userdata('email')))
        $this->session->unset_userdata('email'); 
        if(!empty( $this->session->userdata('admin_email')))
        $this->session->unset_userdata('admin_email'); 
        redirect(base_url());  
    }  
  
}  
?>  