<?php
class DashboardController extends CI_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url','form');
        $this->load->helper('security');  
        $this->load->library('form_validation');
        $this->load->model('User_model');
        $this->load->model('Product_model');
        $this->load->library("pagination");
    }
    public function dashboard()
    {
        //echo $this->session->userdata('email');
        if(!empty( $this->session->userdata('email'))){
            $data['fullname']=$this->User_model->getName($this->session->userdata('email'));
            //print_r($data);
            $data['data'] = $this->Product_model->getProduct();  
            //print_r($data);          
            $this->load->view('dashboard',$data);  
        }else{
            $this->session->set_userdata(array('expired'=>'Session expired'));  
            $this->load->view('login');
        }     
         
    }
    public function add_product(){
      if(!empty( $this->session->userdata('email'))){

        if($this->input->post('save'))
        {
            //echo "sim";
            $this->form_validation->set_rules('pdt_name', 'Product Name', 'required');
            $this->form_validation->set_rules('pdt_price', 'Product Price', 'required');  
            $this->form_validation->set_rules('pdt_color', 'Product Color', 'required'); 

            if($this->form_validation->run()){

                $config['upload_path'] = './assets/images';
                //echo $config['upload_path'];
                //die;
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 2000;
                $config['max_width'] = 1500;
                $config['max_height'] = 1500;

                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('pdt_image')) {

                    $data['error'] = $this->upload->display_errors();
                    //print_r(expression)
                    //$this->load->view('files/upload_form', $error);
                }else{ 
                  $email=$this->input->post('email');
                  $name=$this->input->post('pdt_name');
                  $price=$this->input->post('pdt_price');
                  $color=$this->input->post('pdt_color');
                  $status=$this->input->post('status');
                  $user_id=$this->User_model->getUserId($email);
                  
                  $que=$this->db->query("select * from product_details where name='".$name."'");
                  $row = $que->num_rows();
                  if($row)
                  {
                  $data['error']="<h3 style='color:red'>Product Name already exists</h3>";
                  }
                  else
                  {
                      $data1 = array(
                          'user_id'=>$user_id,
                          'name'=>$name,
                          'price'=>$price,
                          'color'=>$color,
                          'image' => $_FILES['pdt_image']['name'],
                          'status'=>$status
                      );

                      $this->db->insert('product_details',$data1);
                      $data['error']="<h3 style='color:blue'>Your Product added successfully</h3>";
                  }
                }
                print_r($data["error"]);
            }           
                
        }

            $this->load->view('add_product',@data);  
        }else{
            $this->session->set_userdata(array('expired'=>'Session expired'));  
            $this->load->view('login');
        }    
    }
    public function admin_dashboard(){
        if(!empty( $this->session->userdata('admin_email'))){
            $data['count_users']=$this->User_model->get_count();
            $data['product_users']=$this->Product_model->countProduct();
            $this->load->view('admin_dashboard',$data);  
        }else{
            $this->session->set_userdata(array('expired'=>'Session expired'));  
            $this->load->view('login');
        }
    }
    public function searchText(){
        $searchQuery=$this->input->post('searchQuery').'%';
        $fullname=$this->User_model->getName($this->session->userdata('email'));
        $data=$this->Product_model->searchByName($searchQuery);

        if(!empty($data)){
          ?>
        <table id="product_details">
          <tr>
            <th>SL No.</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Color</th>
            <th>Action</th>
          </tr>
          <?php
          foreach($data as $key=>$product){
            ?>
              <tr>
              <td><?php echo $key+1;?></td>
              <td><?php echo $product->name;?></td>
              <td><?php echo $product->price;?></td>
              <td><?php echo $product->color;?></td>
              <td><button id="edit">Edit</button></td>
            </tr>
            <?php
          }
          ?>
          </table>
          <?php

        }
    }
    public function all_user_list(){
      if(!empty( $this->session->userdata('admin_email'))){
            //$data['user']=$this->User_model->getUser();

            $config = array();
            $config["base_url"] = base_url() . "index.php/all_user_list";
            $config["total_rows"] = $this->User_model->get_count();
            $config["per_page"] = 2;
            $config["uri_segment"] = 2;


            $this->pagination->initialize($config);

            $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

            $data["links"] = $this->pagination->create_links();

            $data['user'] = $this->User_model->getOwner($config["per_page"], $page);

            $this->load->view('all_user_list',$data);  
        }else{
            $this->session->set_userdata(array('expired'=>'Session expired'));  
            $this->load->view('login');
        }
    }
    public function product_list(){
      if(!empty( $this->session->userdata('admin_email'))){
            //$data['user']=$this->User_model->getUser();
            //echo $this->Product_model->countProduct();
            //die;
            $config = array();
            $config["base_url"] = base_url() . "index.php/product_list";
            $config["total_rows"] = $this->Product_model->countProduct();
            $config["per_page"] = 3;
            $config["uri_segment"] = 2;


            $this->pagination->initialize($config);

            $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

            $data["links"] = $this->pagination->create_links();

            $data['user'] = $this->Product_model->getProductDetails($config["per_page"], $page);

            $this->load->view('product_list',$data);  
        }else{
            $this->session->set_userdata(array('expired'=>'Session expired'));  
            $this->load->view('login');
        }
    }
    public function searchProduct(){
        $searchQuery=$this->input->post('searchQuery').'%';
        $data=$this->Product_model->searchByProductName($searchQuery);
        //print_r($data);
        ?>
         <table id="product_details">
              <tr>
                <th>SL No.</th>
                <th>Product Owner</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Status</th>
              </tr>
              <?php
        foreach($data as $key=>$pdt){
          $query = $this->db->query("SELECT `name` FROM `user` WHERE id='".$pdt->user_id."'");
          $owner_name = $query->result_array();
          //print_r($owner_name[0]['name']);
          //die;
          foreach ($owner_name as $key => $user) {
             ?>
              <tr>
                <td><?php echo $key+1;?></td>
                <td><?php echo $user['name'];?></td>
                <td><?php echo $pdt->name;?></td>
                <td><?php echo $pdt->price;?></td>
                <td><?php echo $pdt->status;?></td>
              </tr>
             <?php
          }
        }
        
    }
    public function searchOwnerName(){
        $searchQuery=$this->input->post('searchQuery').'%';
        $data=$this->Product_model->searchByOwnerName($searchQuery);
        ?>
        <table id="product_details">
          <tr>
            <th>SL No.</th>
            <th>User Name</th>
            <th>Count</th>
          </tr>
          <?php
          foreach ($data as $key => $user) {
            $query = $this->db->query("SELECT COUNT(`user_id`) AS count FROM `product_details` WHERE user_id='".$user->id."'");
            //echo $this->db->last_query();
            $total_count = $query->result_array();
             ?>
              <tr>
                <td><?php echo $key+1;?></td>
                <td><?php echo $user->name;?></td>
                <td><?php echo $total_count[0]['count'];?></td>
              </tr>
            <?php            
          }
          
      }
}
?>