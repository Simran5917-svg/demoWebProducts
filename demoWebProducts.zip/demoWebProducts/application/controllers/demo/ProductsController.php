<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class ProductsController extends CI_Controller {  
      

    public function __construct()
    {
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
        $this->load->model('User_model');
        $this->load->model('Product_model');
        $this->load->helper('security','url');  
        $this->load->library('form_validation');  
    }
    public function index()  
    {  
        $data['products']=$this->Product_model->getProducts();
        $this->load->view('demo/products',$data);
    }
    public function product_details(){
        $count=$this->Product_model->isProductExist(str_replace("_"," ",$this->uri->segment(2)));
        if($count == 1){
            $data['product']=$this->Product_model->getPdt(str_replace("_"," ",$this->uri->segment(2)));
           //print_r($data);
           $this->load->view('demo/product_details',$data);
        }
        else
            $this->load->view('demo/error404_page');
        
    }
}