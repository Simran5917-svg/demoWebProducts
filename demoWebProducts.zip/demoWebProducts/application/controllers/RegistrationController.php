<?php
class RegistrationController extends CI_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->helper('security');  
        $this->load->library('form_validation');
    }

    public function register()
    {
        
        if($this->input->post('register'))
        {
            //echo "sim";
            $this->form_validation->set_rules('name', 'Name:', 'required');
            $this->form_validation->set_rules('email', 'Email:', 'required|valid_email');  
            $this->form_validation->set_rules('pass', 'Password:', 'required'); 
            $this->form_validation->set_rules('type', 'Type:', 'required');

            if($this->form_validation->run()){

                $n=$this->input->post('name');
                $e=$this->input->post('email');
                $p=$this->input->post('pass');
                $t=$this->input->post('type');
                
                $que=$this->db->query("select * from user where email='".$e."'");
                $row = $que->num_rows();
                if($row)
                {
                $data['error']="<h3 style='color:red'>This user already exists</h3>";
                }
                else
                {
                    $data1 = array(
                        'email'=>$e,
                        'password'=>md5($p),
                        'name'=>$n,
                        'type'=>$t
                    );

                    $this->db->insert('user',$data1);
                
                $data['error']="<h3 style='color:blue'>Your account created successfully</h3>";
                }
            }           
                
        }
        $this->load->view('registration',@$data);   
    }
}
?>