<?php 
class Product_model extends CI_Model {

  public function getProduct(){
 
    // Select record
      $query = $this->db->get('product_details');
	  return $query->result();
  }
  public function getProducts(){
 
    // Select record
      $query = $this->db->query("select * from `product_details` where status!=0");
      return $query->result();
  }
  public function searchByName($searchQuery){

    $query = $this->db->query("select * from `product_details` where (name LIKE '".$searchQuery."')");
    return $query->result();

  }
  public function searchByProductName($searchQuery){
  	$query = $this->db->query("select * from `product_details` where (name LIKE '".$searchQuery."')");
    return $query->result();
  }
  public function searchByOwnerName($searchQuery){
  	$query = $this->db->query("select `id`,`name` from `user` where (name LIKE '".$searchQuery."') && type!='admin'");
    return $query->result();
  }
  public function countProduct(){
    $query = $this->db->query("SELECT COUNT(*) AS COUNT FROM user,product_details WHERE user.id = product_details.user_id && type!='admin'");
    $data = $query->result_array();
     return ($data[0]['COUNT']);
  }
  public function getProductDetails($limit, $start){
    $query = $this->db->query("SELECT user.name As ownerName,product_details.name,product_details.price,product_details.status FROM user,product_details WHERE user.id = product_details.user_id && user.type!='admin' LIMIT ".$limit." OFFSET  ".$start."");
    $data = $query->result_array();
    return $data;
    //die;
  }
  public function getPdt($productName){
         $query = $this->db->query("SELECT user.name As ownerName,product_details.name,product_details.price,product_details.color,product_details.image FROM user,product_details WHERE user.id = product_details.user_id && product_details.name='".$productName."'");
    $data = $query->result_array();
    //echo $this->db->last_query();
    return $data;
  }
  Public function isProductExist($productName){
    $query = $this->db->query("SELECT COUNT(*) AS COUNT FROM product_details WHERE name='".$productName."'");
    $data = $query->result_array();
     return ($data[0]['COUNT']);
  }
}
?>