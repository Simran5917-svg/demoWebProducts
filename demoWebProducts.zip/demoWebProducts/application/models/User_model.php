<?php 
class User_model extends CI_Model {

  public function getUsers($email){
 
    // Select record
    $query = $this->db->get_where('user', array('email'=>$email));
	  return $query->result();
  }
  public function getName($email){
    $query = $this->db->query("SELECT `name` FROM user where email='".$email."'");
    $data = $query->result_array();
    return $data[0]['name'];
  }
  public function getUserId($email){
 
    // Select record
    $this->db->select('id');
    $this->db->where('email',$email);
    $q = $this->db->get('user');
    $data = $q->result_array();
    return $data[0]['id'];
  }
  public function getUser(){
    $query = $this->db->query("SELECT `id`,`name` FROM user where type!='admin'");
    $data = $query->result_array();
    return $data;
  }
  public function getOwner($limit, $start){
    $query = $this->db->query("SELECT `id`,`name` FROM user where type!='admin' LIMIT ".$limit." OFFSET  ".$start."");
    $data = $query->result_array();
    return $data;
  }
  
  public function get_count() {
        $query = $this->db->query("SELECT COUNT(*) AS COUNT FROM user WHERE type!='admin'");
        $data = $query->result();
        //print_r($data);
        return $data[0]->COUNT;
    }

}
?>